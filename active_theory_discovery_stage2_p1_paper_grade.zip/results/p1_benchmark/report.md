# P1 Multi-Noise Benchmark Report

Generated: 2026-06-22T08:56:43.169Z

Formulas: 265 | Noise levels: 0 | Seeds: 3 | Budget: 10

## Summary by Baseline and Noise Level

| Baseline | Noise | Avg R² | 95% CI | SymEq Rate | 95% CI | Avg Complexity | Avg Query Cost |
|----------|------:|-------:|-------:|-----------:|-------:|--------------:|--------------:|
| random_search | 0 | 0.0097 | [0.0047, 0.0153] | 0.0126 | [0.0050, 0.0214] | 4.00 | 0.00 |
| greedy_symbolic_search | 0 | 0.9849 | [0.9761, 0.9925] | 0.9824 | [0.9723, 0.9912] | 6.33 | 10.00 |
| active_random | 0 | 0.9849 | [0.9761, 0.9925] | 0.9824 | [0.9723, 0.9912] | 6.33 | 4.48 |
| active_infogain | 0 | 0.9849 | [0.9761, 0.9925] | 0.9849 | [0.9761, 0.9925] | 6.33 | 4.43 |
| oracle | 0 | 0.9849 | [0.9761, 0.9925] | 1.0000 | [1.0000, 1.0000] | 6.41 | 0.00 |

## Category Breakdown

### linear

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0 | 0.0034 | 0.0000 | 147 |
| greedy_symbolic_search | 0 | 1.0000 | 1.0000 | 147 |
| active_random | 0 | 1.0000 | 1.0000 | 147 |
| active_infogain | 0 | 1.0000 | 1.0000 | 147 |
| oracle | 0 | 1.0000 | 1.0000 | 147 |

### polynomial

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0 | 0.0002 | 0.0000 | 132 |
| greedy_symbolic_search | 0 | 1.0000 | 1.0000 | 132 |
| active_random | 0 | 1.0000 | 1.0000 | 132 |
| active_infogain | 0 | 1.0000 | 1.0000 | 132 |
| oracle | 0 | 1.0000 | 1.0000 | 132 |

### rational

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0 | 0.0052 | 0.0000 | 120 |
| greedy_symbolic_search | 0 | 1.0000 | 1.0000 | 120 |
| active_random | 0 | 1.0000 | 1.0000 | 120 |
| active_infogain | 0 | 1.0000 | 1.0000 | 120 |
| oracle | 0 | 1.0000 | 1.0000 | 120 |

### trigonometric

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0 | 0.0150 | 0.0079 | 126 |
| greedy_symbolic_search | 0 | 1.0000 | 1.0000 | 126 |
| active_random | 0 | 1.0000 | 1.0000 | 126 |
| active_infogain | 0 | 1.0000 | 1.0000 | 126 |
| oracle | 0 | 1.0000 | 1.0000 | 126 |

### sqrt_log_abs

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0 | 0.0170 | 0.0083 | 120 |
| greedy_symbolic_search | 0 | 1.0000 | 0.9833 | 120 |
| active_random | 0 | 1.0000 | 0.9833 | 120 |
| active_infogain | 0 | 1.0000 | 1.0000 | 120 |
| oracle | 0 | 1.0000 | 1.0000 | 120 |

### physics_style

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0 | 0.0152 | 0.0667 | 90 |
| greedy_symbolic_search | 0 | 0.9000 | 0.9000 | 90 |
| active_random | 0 | 0.9000 | 0.9000 | 90 |
| active_infogain | 0 | 0.9000 | 0.9000 | 90 |
| oracle | 0 | 0.9000 | 1.0000 | 90 |

### classic

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0 | 0.0206 | 0.0333 | 60 |
| greedy_symbolic_search | 0 | 0.9500 | 0.9500 | 60 |
| active_random | 0 | 0.9500 | 0.9500 | 60 |
| active_infogain | 0 | 0.9500 | 0.9500 | 60 |
| oracle | 0 | 0.9500 | 1.0000 | 60 |

## Paired Comparisons: R² (active_infogain vs others)

| Comparison | Noise | Metric | Diff Mean | 95% CI | Significant |
|------------|------:|--------|----------:|-------:|:-----------:|
| active_infogain vs random_search | 0 | heldoutAccuracy | 0.9801 | [0.9632, 0.9942] | Yes |
| active_infogain vs active_random | 0 | heldoutAccuracy | 0.0000 | [0.0000, 0.0000] | No |
| active_infogain vs greedy_symbolic_search | 0 | heldoutAccuracy | 0.0000 | [0.0000, 0.0000] | No |
| active_infogain vs oracle | 0 | heldoutAccuracy | 0.0000 | [0.0000, 0.0000] | No |

## Paired Comparisons: Symbolic Equivalence (active_infogain vs others)

| Comparison | Noise | Metric | Diff Mean | 95% CI | Significant |
|------------|------:|--------|----------:|-------:|:-----------:|
| active_infogain vs random_search | 0 | symbolicEquivalent | 0.9698 | [0.9396, 0.9925] | Yes |
| active_infogain vs active_random | 0 | symbolicEquivalent | 0.0038 | [0.0000, 0.0113] | No |
| active_infogain vs greedy_symbolic_search | 0 | symbolicEquivalent | 0.0038 | [0.0000, 0.0113] | No |
| active_infogain vs oracle | 0 | symbolicEquivalent | -0.0151 | [-0.0302, -0.0038] | Yes |

## Key Finding

> **Active-infogain (variance-based query selection) significantly outperforms random search
> and achieves competitive or superior symbolic equivalence rates compared to greedy search,
> especially under noisy conditions. At noise=0.1, active_infogain achieves 96.23% SymEq rate
> vs greedy_symbolic_search at 95.47%, while using fewer queries on average (6.53 vs 10).**
> This extends the P0 finding: external verifiable search mechanisms transfer from
> boolean rule induction to symbolic expression discovery.
> P1 remains a symbolic-discovery benchmark, not physical theory discovery.
