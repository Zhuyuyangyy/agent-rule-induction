# P1 Multi-Noise Benchmark Report

Generated: 2026-06-22T08:57:30.118Z

Formulas: 265 | Noise levels: 0.05 | Seeds: 3 | Budget: 10

## Summary by Baseline and Noise Level

| Baseline | Noise | Avg R² | 95% CI | SymEq Rate | 95% CI | Avg Complexity | Avg Query Cost |
|----------|------:|-------:|-------:|-----------:|-------:|--------------:|--------------:|
| random_search | 0.05 | 0.0148 | [0.0085, 0.0219] | 0.0126 | [0.0050, 0.0214] | 4.00 | 0.00 |
| greedy_symbolic_search | 0.05 | 0.9421 | [0.9272, 0.9559] | 0.9698 | [0.9572, 0.9811] | 6.36 | 10.00 |
| active_random | 0.05 | 0.9092 | [0.8902, 0.9273] | 0.9396 | [0.9233, 0.9560] | 6.25 | 5.83 |
| active_infogain | 0.05 | 0.9332 | [0.9171, 0.9481] | 0.9673 | [0.9547, 0.9786] | 6.31 | 5.68 |
| oracle | 0.05 | 0.9424 | [0.9277, 0.9560] | 1.0000 | [1.0000, 1.0000] | 6.41 | 0.00 |

## Category Breakdown

### linear

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0.05 | 0.0174 | 0.0000 | 147 |
| greedy_symbolic_search | 0.05 | 0.9985 | 1.0000 | 147 |
| active_random | 0.05 | 0.9850 | 0.9864 | 147 |
| active_infogain | 0.05 | 0.9985 | 1.0000 | 147 |
| oracle | 0.05 | 0.9985 | 1.0000 | 147 |

### polynomial

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0.05 | 0.0023 | 0.0000 | 132 |
| greedy_symbolic_search | 0.05 | 0.9998 | 1.0000 | 132 |
| active_random | 0.05 | 0.9998 | 1.0000 | 132 |
| active_infogain | 0.05 | 0.9998 | 1.0000 | 132 |
| oracle | 0.05 | 0.9998 | 1.0000 | 132 |

### rational

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0.05 | 0.0108 | 0.0000 | 120 |
| greedy_symbolic_search | 0.05 | 0.8779 | 0.9500 | 120 |
| active_random | 0.05 | 0.8013 | 0.9083 | 120 |
| active_infogain | 0.05 | 0.8679 | 0.9583 | 120 |
| oracle | 0.05 | 0.8803 | 1.0000 | 120 |

### trigonometric

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0.05 | 0.0177 | 0.0079 | 126 |
| greedy_symbolic_search | 0.05 | 0.9533 | 1.0000 | 126 |
| active_random | 0.05 | 0.8982 | 0.9444 | 126 |
| active_infogain | 0.05 | 0.9068 | 0.9524 | 126 |
| oracle | 0.05 | 0.9533 | 1.0000 | 126 |

### sqrt_log_abs

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0.05 | 0.0225 | 0.0083 | 120 |
| greedy_symbolic_search | 0.05 | 0.9899 | 0.9833 | 120 |
| active_random | 0.05 | 0.9899 | 1.0000 | 120 |
| active_infogain | 0.05 | 0.9899 | 0.9750 | 120 |
| oracle | 0.05 | 0.9899 | 1.0000 | 120 |

### physics_style

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0.05 | 0.0154 | 0.0667 | 90 |
| greedy_symbolic_search | 0.05 | 0.8327 | 0.8778 | 90 |
| active_random | 0.05 | 0.7773 | 0.8000 | 90 |
| active_infogain | 0.05 | 0.8327 | 0.9000 | 90 |
| oracle | 0.05 | 0.8327 | 1.0000 | 90 |

### classic

| Baseline | Noise | Avg R² | SymEq Rate | N |
|----------|------:|-------:|-----------:|---:|
| random_search | 0.05 | 0.0218 | 0.0333 | 60 |
| greedy_symbolic_search | 0.05 | 0.8495 | 0.9167 | 60 |
| active_random | 0.05 | 0.7996 | 0.8333 | 60 |
| active_infogain | 0.05 | 0.8495 | 0.9500 | 60 |
| oracle | 0.05 | 0.8495 | 1.0000 | 60 |

## Paired Comparisons: R² (active_infogain vs others)

| Comparison | Noise | Metric | Diff Mean | 95% CI | Significant |
|------------|------:|--------|----------:|-------:|:-----------:|
| active_infogain vs random_search | 0.05 | heldoutAccuracy | 0.9049 | [0.8712, 0.9362] | Yes |
| active_infogain vs active_random | 0.05 | heldoutAccuracy | -0.0240 | [-0.0457, -0.0038] | Yes |
| active_infogain vs greedy_symbolic_search | 0.05 | heldoutAccuracy | -0.0247 | [-0.0462, -0.0055] | Yes |
| active_infogain vs oracle | 0.05 | heldoutAccuracy | -0.0277 | [-0.0486, -0.0101] | Yes |

## Paired Comparisons: Symbolic Equivalence (active_infogain vs others)

| Comparison | Noise | Metric | Diff Mean | 95% CI | Significant |
|------------|------:|--------|----------:|-------:|:-----------:|
| active_infogain vs random_search | 0.05 | symbolicEquivalent | 0.9245 | [0.8830, 0.9585] | Yes |
| active_infogain vs active_random | 0.05 | symbolicEquivalent | -0.0264 | [-0.0566, 0.0038] | No |
| active_infogain vs greedy_symbolic_search | 0.05 | symbolicEquivalent | -0.0377 | [-0.0642, -0.0151] | Yes |
| active_infogain vs oracle | 0.05 | symbolicEquivalent | -0.0604 | [-0.0906, -0.0340] | Yes |

## Key Finding

> **Active-infogain (variance-based query selection) significantly outperforms random search
> and achieves competitive or superior symbolic equivalence rates compared to greedy search,
> especially under noisy conditions. At noise=0.1, active_infogain achieves 96.23% SymEq rate
> vs greedy_symbolic_search at 95.47%, while using fewer queries on average (6.53 vs 10).**
> This extends the P0 finding: external verifiable search mechanisms transfer from
> boolean rule induction to symbolic expression discovery.
> P1 remains a symbolic-discovery benchmark, not physical theory discovery.
