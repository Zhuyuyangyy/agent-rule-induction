# P0 Rule Induction Benchmark Report

Generated: 2026-06-20T15:34:32.455Z

## Oracle Upper Bound

| Metric | Value |
|--------|-------|
| Accuracy (theoretical max) | 1.000 |
| Avg Queries (optimal) | 3.34 |
| VS Size One Rate | 1.000 |
| Avg Final VS | 1.00 |

Oracle (version-space) uses greedy information-gain queries and always selects the true rule. Accuracy=1.0 is the theoretical upper bound. avgQueries is the minimum query cost under optimal strategy. vsSizeOneRate is the fraction of tasks fully solvable (VS reduced to 1) within the query budget.

## Metrics by Condition

| Condition | Tasks | Accuracy | Avg Queries | Avg Tokens | Avg Final VS | Invalid Rate | Efficiency |
|-----------|-------|----------|-------------|------------|--------------|--------------|------------|
| algorithmic_random_query | 100 | 62.0% | 4.82 | 0 | 2.39 | 0.0% | 0.129 |
| algorithmic_infogain | 100 | 100.0% | 3.34 | 0 | 1.00 | 0.0% | 0.299 |
| oracle_version_space | 100 | 100.0% | 3.34 | 0 | 1.00 | 0.0% | 0.299 |
| llm_active | 100 | 17.0% | 4.74 | 3754 | 2.39 | 0.0% | 0.036 |
| llm_passive | 100 | 4.0% | 0.00 | 357 | 12.18 | 1.0% | 0.040 |
| llm_scaffold | 100 | 27.0% | 4.53 | 7621 | 3.21 | 0.0% | 0.060 |

## Failure Type Breakdown

| Condition | correct | wrong_rule | insufficient_queries | invalid_json | overconfident_guess | version_space_mismatch | timeout | api_error |
|-----------|---------|---------|---------|---------|---------|---------|---------|---------|
| algorithmic_random_query | 62 | 0 | 0 | 0 | 0 | 38 | 0 | 0 |
| algorithmic_infogain | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| oracle_version_space | 100 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| llm_active | 17 | 29 | 0 | 0 | 30 | 24 | 0 | 0 |
| llm_passive | 4 | 0 | 0 | 0 | 96 | 0 | 0 | 0 |
| llm_scaffold | 27 | 29 | 0 | 0 | 14 | 30 | 0 | 0 |

## Significance Tests

| Comparison | Metric | Mean A | Mean B | t-stat | p-value | Cohen's d | Significant |
|------------|--------|--------|--------|--------|---------|-----------|-------------|
| algorithmic_random_query vs algorithmic_infogain | accuracy | 0.620 | 1.000 | 7.790 | 0.0000 | 0.779 | Yes |
| algorithmic_random_query vs oracle_version_space | accuracy | 0.620 | 1.000 | 7.790 | 0.0000 | 0.779 | Yes |
| algorithmic_random_query vs llm_active | accuracy | 0.620 | 0.170 | -6.693 | 0.0000 | -0.669 | Yes |
| algorithmic_random_query vs llm_passive | accuracy | 0.620 | 0.040 | -11.240 | 0.0000 | -1.124 | Yes |
| algorithmic_random_query vs llm_scaffold | accuracy | 0.620 | 0.270 | -5.206 | 0.0000 | -0.521 | Yes |
| algorithmic_infogain vs oracle_version_space | query_count | 3.340 | 3.340 | 0.000 | 1.0000 | 0.000 | No |


Total failure cases: 290
